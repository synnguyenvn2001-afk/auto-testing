# Facebook Redirect Checker - khong can dang nhap

Tool nay chi lam mot viec: mo tung URL Facebook trong Chromium **khong dang nhap**, cho redirect on dinh, sau do ghi lai URL cuoi cung va so sanh voi URL goc.

Vi du:

- URL goc: `https://www.facebook.com/groups/477220950105282/posts/25962265036690693/`
- URL sau redirect: `https://www.facebook.com/groups/2417591631584698/posts/25962265036690693/`
- `url_changed = True`
- `group_changed = True`
- `status = GROUP_CHANGED`

## Cach dung tren Windows

1. Giai nen ZIP.
2. Chay `setup_windows.bat` mot lan.
3. Test nhanh: chay `test_1_url.bat`.
4. Check file hien tai: chay `run_current_file.bat`.
5. Check file khac: keo-tha CSV/XLSX vao `run_checker.bat`.

Khong co buoc dang nhap Facebook. Tool tao mot browser context moi moi lan chay va khong luu session.

## Ket qua

Tool tao hai file canh file input:

- `<ten_file>_redirect_checked.csv`
- `<ten_file>_redirect_checked.xlsx`

Cac cot quan trong:

- `url_goc`: URL ban dau.
- `final_url`: URL tren thanh dia chi sau redirect.
- `url_changed`: `True` neu URL co thay doi co y nghia.
- `group_id_goc`: group ID ban dau.
- `group_id_sau`: group ID sau redirect.
- `group_changed`: `True` neu group ID thay doi.
- `post_id_goc`, `post_id_sau`, `post_id_same`: de xac nhan post van la cung mot post.
- `status`:
  - `SAME_URL`: khong doi.
  - `GROUP_CHANGED`: group ID doi.
  - `URL_CHANGED`: URL doi nhung van la group URL.
  - `LOGIN_REDIRECT`: bi dua sang trang login.
  - `REDIRECT_OTHER`: redirect sang dang URL khac.

Tool bo qua khac biet chi do query tracking, fragment, `m.facebook.com`/`www.facebook.com` va dau `/` cuoi URL de tranh bao sai.

## Lenh truc tiep

```bat
python fb_redirect_checker.py data-1787136301628.csv --resume
```

Chi test 5 dong:

```bat
python fb_redirect_checker.py data-1787136301628.csv --limit 5
```

Chay an cua so Chromium:

```bat
python fb_redirect_checker.py data-1787136301628.csv --headless
```

Mac dinh tool de browser hien thi vi cach nay gan voi viec ban paste URL vao Chrome hon headless.
