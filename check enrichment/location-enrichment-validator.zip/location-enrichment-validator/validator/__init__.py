"""Location enrichment validation package."""
