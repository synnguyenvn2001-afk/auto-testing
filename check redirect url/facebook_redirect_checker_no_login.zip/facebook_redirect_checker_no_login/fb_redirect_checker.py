#!/usr/bin/env python3
"""Anonymous Facebook group URL redirect checker.

Reads CSV/XLSX containing a URL column, opens each Facebook group post URL in a
fresh Chromium session without logging in, records the final browser URL after
redirects settle, and reports whether the canonical URL/group changed.
"""

from __future__ import annotations

import argparse
import random
import re
import sys
import time
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlsplit, urlunsplit

import pandas as pd
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

FB_GROUP_POST_RE = re.compile(
    r"https?://(?:www\.|m\.|mbasic\.)?facebook\.com/groups/([^/?#]+)/(?:posts|permalink)/([^/?#]+)",
    re.IGNORECASE,
)
FB_GROUP_RE = re.compile(
    r"https?://(?:www\.|m\.|mbasic\.)?facebook\.com/groups/([^/?#]+)",
    re.IGNORECASE,
)

RESULT_COLUMNS = [
    "url_goc",
    "final_url",
    "url_changed",
    "group_id_goc",
    "group_id_sau",
    "group_changed",
    "post_id_goc",
    "post_id_sau",
    "post_id_same",
    "status",
    "check_error",
]


def parse_group_post(url: str) -> Tuple[Optional[str], Optional[str]]:
    if not url:
        return None, None
    m = FB_GROUP_POST_RE.search(url)
    if m:
        return m.group(1), m.group(2)
    m = FB_GROUP_RE.search(url)
    if m:
        return m.group(1), None
    return None, None


def canonical_url(url: str) -> str:
    """Normalize cosmetic differences while preserving the meaningful path.

    For group/post URLs, canonicalize host/query/fragment/trailing slash so that
    Facebook-added tracking parameters do not count as a meaningful change.
    """
    if not url:
        return ""
    group_id, post_id = parse_group_post(url)
    if group_id and post_id:
        return f"https://www.facebook.com/groups/{group_id}/posts/{post_id}/"
    if group_id:
        return f"https://www.facebook.com/groups/{group_id}/"

    try:
        parts = urlsplit(url.strip())
        host = parts.netloc.lower()
        if host in {"facebook.com", "m.facebook.com", "mbasic.facebook.com"}:
            host = "www.facebook.com"
        path = parts.path or "/"
        if path != "/":
            path = path.rstrip("/") + "/"
        return urlunsplit((parts.scheme.lower() or "https", host, path, "", ""))
    except Exception:
        return url.strip()


def read_input(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, dtype=str, keep_default_na=False, na_filter=False)
    if suffix in {".xlsx", ".xlsm"}:
        return pd.read_excel(path, dtype=str, keep_default_na=False)
    raise ValueError("Chi ho tro file .csv, .xlsx hoac .xlsm")


def write_outputs(df: pd.DataFrame, csv_path: Path, xlsx_path: Path) -> None:
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    df.to_excel(xlsx_path, index=False, engine="openpyxl")


def wait_url_stable(page, max_wait_seconds: float = 7.0, stable_seconds: float = 1.5) -> str:
    deadline = time.monotonic() + max_wait_seconds
    last = page.url
    last_change = time.monotonic()

    while time.monotonic() < deadline:
        page.wait_for_timeout(250)
        current = page.url
        if current != last:
            last = current
            last_change = time.monotonic()
        elif time.monotonic() - last_change >= stable_seconds:
            break
    return page.url


def check_one(page, original_url: str, timeout_ms: int) -> dict:
    original_url = (original_url or "").strip()
    original_group, original_post = parse_group_post(original_url)

    result = {
        "url_goc": original_url,
        "final_url": "",
        "url_changed": "",
        "group_id_goc": original_group or "",
        "group_id_sau": "",
        "group_changed": "",
        "post_id_goc": original_post or "",
        "post_id_sau": "",
        "post_id_same": "",
        "status": "",
        "check_error": "",
    }

    if not original_url:
        result["status"] = "EMPTY_URL"
        return result

    nav_error = ""
    try:
        page.goto(original_url, wait_until="domcontentloaded", timeout=timeout_ms)
    except PlaywrightTimeoutError as exc:
        nav_error = f"goto timeout: {exc}"
    except Exception as exc:  # keep processing remaining rows
        nav_error = f"goto error: {type(exc).__name__}: {exc}"

    try:
        final_url = wait_url_stable(page)
    except Exception as exc:
        final_url = page.url
        nav_error = (nav_error + " | " if nav_error else "") + f"settle error: {type(exc).__name__}: {exc}"

    final_group, final_post = parse_group_post(final_url)
    result["final_url"] = final_url
    result["group_id_sau"] = final_group or ""
    result["post_id_sau"] = final_post or ""

    changed = canonical_url(final_url) != canonical_url(original_url)
    result["url_changed"] = changed

    if original_group and final_group:
        result["group_changed"] = final_group != original_group
    if original_post and final_post:
        result["post_id_same"] = final_post == original_post

    if original_group and final_group and final_group != original_group:
        result["status"] = "GROUP_CHANGED"
    elif not changed:
        result["status"] = "SAME_URL"
    elif final_group:
        result["status"] = "URL_CHANGED"
    else:
        lower = final_url.lower()
        if "/login" in lower or "/checkpoint" in lower:
            result["status"] = "LOGIN_REDIRECT"
        else:
            result["status"] = "REDIRECT_OTHER"

    result["check_error"] = nav_error
    return result


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Check redirect URL Facebook group ma khong can dang nhap.")
    p.add_argument("input_file", help="File CSV/XLSX co cot URL")
    p.add_argument("--url-column", default="url", help="Ten cot URL, mac dinh: url")
    p.add_argument("--output", default=None, help="Ten file output khong can duoi mo rong")
    p.add_argument("--timeout", type=int, default=30, help="Timeout moi URL, giay")
    p.add_argument("--delay-min", type=float, default=0.8, help="Delay toi thieu giua cac URL, giay")
    p.add_argument("--delay-max", type=float, default=1.5, help="Delay toi da giua cac URL, giay")
    p.add_argument("--save-every", type=int, default=10, help="Luu checkpoint moi N URL")
    p.add_argument("--limit", type=int, default=None, help="Chi check N dong dau")
    p.add_argument("--headless", action="store_true", help="An cua so Chromium")
    p.add_argument("--resume", action="store_true", help="Tiep tuc tu output cu neu co")
    return p


def main() -> int:
    args = build_parser().parse_args()
    input_path = Path(args.input_file).expanduser().resolve()
    if not input_path.exists():
        print(f"Khong tim thay file: {input_path}", file=sys.stderr)
        return 2

    try:
        df = read_input(input_path)
    except Exception as exc:
        print(f"Khong doc duoc file: {exc}", file=sys.stderr)
        return 2

    if args.url_column not in df.columns:
        print(f"Khong co cot '{args.url_column}'. Cot hien co: {', '.join(map(str, df.columns))}", file=sys.stderr)
        return 2

    for col in df.columns:
        df[col] = df[col].astype(str)
    for col in RESULT_COLUMNS:
        if col not in df.columns:
            df[col] = ""

    output_base = Path(args.output).expanduser().resolve() if args.output else input_path.with_name(input_path.stem + "_redirect_checked")
    if output_base.suffix.lower() in {".csv", ".xlsx"}:
        output_base = output_base.with_suffix("")
    csv_out = output_base.with_suffix(".csv")
    xlsx_out = output_base.with_suffix(".xlsx")

    if args.resume and csv_out.exists():
        old = pd.read_csv(csv_out, dtype=str, keep_default_na=False, na_filter=False)
        if len(old) == len(df) and args.url_column in old.columns:
            same_url = old[args.url_column].astype(str) == df[args.url_column].astype(str)
            for col in RESULT_COLUMNS:
                if col in old.columns:
                    df.loc[same_url, col] = old.loc[same_url, col].astype(str)
            print(f"Resume tu: {csv_out}")

    indices = list(range(len(df)))
    if args.limit is not None:
        indices = indices[: max(args.limit, 0)]

    completed = {"SAME_URL", "GROUP_CHANGED", "URL_CHANGED", "LOGIN_REDIRECT", "REDIRECT_OTHER", "EMPTY_URL"}

    print(f"Input: {input_path}")
    print(f"Rows: {len(df)}")
    print("Mode: anonymous / khong dang nhap")
    print(f"Output CSV:  {csv_out}")
    print(f"Output Excel: {xlsx_out}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=args.headless)
        context = browser.new_context(
            viewport={"width": 1280, "height": 900},
            locale="en-US",
        )
        page = context.new_page()

        checked = 0
        for pos, idx in enumerate(indices, start=1):
            old_status = str(df.at[idx, "status"]).strip()
            if args.resume and old_status in completed:
                print(f"[{pos}/{len(indices)}] SKIP {old_status}")
                continue

            url = str(df.at[idx, args.url_column]).strip()
            print(f"[{pos}/{len(indices)}] {url}")
            result = check_one(page, url, args.timeout * 1000)
            for key, value in result.items():
                df.at[idx, key] = value

            arrow = " -> " if result["final_url"] else ""
            print(f"    {result['status']} | changed={result['url_changed']}")
            if result["final_url"]:
                print(f"    {url}{arrow}{result['final_url']}")

            checked += 1
            if args.save_every > 0 and checked % args.save_every == 0:
                write_outputs(df, csv_out, xlsx_out)
                print("    [checkpoint saved]")

            if pos < len(indices):
                time.sleep(random.uniform(args.delay_min, args.delay_max))

        write_outputs(df, csv_out, xlsx_out)
        context.close()
        browser.close()

    counts = df.loc[indices, "status"].value_counts(dropna=False).to_dict()
    changed_count = sum(str(v).lower() == "true" for v in df.loc[indices, "url_changed"].tolist())
    total = len(indices)

    print("\n=== KET QUA ===")
    print(f"URL thay doi: {changed_count}/{total}")
    print(f"URL khong doi: {total - changed_count}/{total}")
    for status, count in counts.items():
        print(f"{status or '(blank)'}: {count}")
    print(f"\nDa luu: {csv_out}")
    print(f"Da luu: {xlsx_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
